-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 04, 2019 at 10:17 AM
-- Server version: 5.7.27-0ubuntu0.18.04.1
-- PHP Version: 7.2.19-0ubuntu0.18.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo_tour`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_mast`
--

CREATE TABLE `account_mast` (
  `id` int(10) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `opening_balance` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_phn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_addr` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `account_mast`
--

INSERT INTO `account_mast` (`id`, `comp_code`, `name`, `opening_balance`, `bank_name`, `bank_phn`, `bank_addr`, `enabled`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '001', 'account LEL', '2000000.0000', 'HDFC BANK', '0171-9980239', 'Indore, Madhya Pradesh', 1, NULL, NULL, NULL),
(2, '002', 'account YIPL', '2000000.0000', 'AXIS BANK', '0171-3823240', 'Indore, Madhya Pradesh', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comp_grp`
--

CREATE TABLE `comp_grp` (
  `grp_code` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grp_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grp_desc` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comp_grp`
--

INSERT INTO `comp_grp` (`grp_code`, `grp_name`, `grp_desc`) VALUES
('1', 'Laxyo Group', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comp_mast`
--

CREATE TABLE `comp_mast` (
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grp_code` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comp_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comp_desc` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `tour_enable` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comp_mast`
--

INSERT INTO `comp_mast` (`comp_code`, `grp_code`, `comp_name`, `comp_desc`, `enabled`, `tour_enable`) VALUES
('000', '1', 'Management', NULL, 1, 0),
('001', '1', 'LEL', NULL, 1, 1),
('002', '1', 'YIPL', NULL, 1, 1),
('003', '1', 'LIS', NULL, 1, 0),
('004', '1', 'DBF', NULL, 1, 0),
('005', '1', 'AMAZON', NULL, 1, 0),
('006', '1', 'APNAGPS', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `desg_mast`
--

CREATE TABLE `desg_mast` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `desg_mast`
--

INSERT INTO `desg_mast` (`id`, `comp_code`, `title`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '000', 'Director1 (Y Sir)', NULL, NULL, NULL, NULL),
(2, '000', 'Director2 (HS Sir)', NULL, NULL, NULL, NULL),
(3, '000', 'HR', NULL, NULL, NULL, NULL),
(4, '001', 'TL', NULL, NULL, NULL, NULL),
(5, '002', 'TL', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `emp_grade_mast`
--

CREATE TABLE `emp_grade_mast` (
  `grade_code` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comp_grp` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entitled_amt` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emp_mast`
--

CREATE TABLE `emp_mast` (
  `emp_id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `emp_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grade_code` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login_user` int(10) UNSIGNED NOT NULL,
  `emp_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_gender` enum('M','F','O') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emp_dob` date DEFAULT NULL,
  `emp_desg` int(10) UNSIGNED DEFAULT NULL,
  `join_dt` date DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `emp_mast`
--

INSERT INTO `emp_mast` (`emp_id`, `parent_id`, `emp_code`, `comp_code`, `grade_code`, `login_user`, `emp_name`, `emp_gender`, `emp_dob`, `emp_desg`, `join_dt`, `active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, NULL, NULL, '000', 'A', 2, 'Y Sir', 'M', '1994-06-26', 1, NULL, 1, NULL, NULL, NULL),
(2, NULL, NULL, '000', 'A', 3, 'HS Sir', 'M', '1994-06-26', 2, NULL, 1, NULL, NULL, NULL),
(3, NULL, NULL, '000', 'A', 4, 'HR - User', 'M', '1994-06-26', 3, NULL, 1, NULL, NULL, NULL),
(4, NULL, NULL, '001', 'A', 5, 'TL comp 1', 'M', '1994-06-26', 4, NULL, 1, NULL, NULL, NULL),
(5, NULL, NULL, '002', 'A', 6, 'TL Comp 2', 'M', '1994-06-26', 5, NULL, 1, NULL, NULL, NULL),
(6, NULL, NULL, '001', 'A', 1, 'Aayush Likhar', 'M', '1993-06-26', 1, NULL, 1, NULL, NULL, NULL),
(7, NULL, NULL, '004', 'A', 7, 'Vinod Kurmi', 'M', '1993-06-26', 1, NULL, 1, NULL, NULL, NULL),
(8, NULL, NULL, '004', 'A', 8, 'Ritesh Panchal', 'M', '1996-06-26', 1, NULL, 1, NULL, NULL, NULL),
(9, NULL, NULL, '004', 'A', 9, 'Abhishek Soni', 'M', '1994-06-26', 1, NULL, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `expense_catg_mast`
--

CREATE TABLE `expense_catg_mast` (
  `id` int(10) UNSIGNED NOT NULL,
  `grp_code` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `expense_catg_mast`
--

INSERT INTO `expense_catg_mast` (`id`, `grp_code`, `name`, `color`, `enabled`) VALUES
(1, '1', 'others', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `expense_in_user`
--

CREATE TABLE `expense_in_user` (
  `emp_id` bigint(20) UNSIGNED NOT NULL,
  `grp_code` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_mode_mast`
--

CREATE TABLE `expense_mode_mast` (
  `id` int(10) UNSIGNED NOT NULL,
  `grp_code` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `expense_mode_mast`
--

INSERT INTO `expense_mode_mast` (`id`, `grp_code`, `name`, `color`, `enabled`) VALUES
(1, '1', 'Cash', NULL, 1),
(2, '1', 'NEFT', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `expense_permit_user`
--

CREATE TABLE `expense_permit_user` (
  `emp_id` bigint(20) UNSIGNED NOT NULL,
  `grp_code` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_site_mast`
--

CREATE TABLE `expense_site_mast` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_desc` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exp_bills`
--

CREATE TABLE `exp_bills` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bill_number` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_number` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bill_status_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billed_at` datetime NOT NULL,
  `due_at` datetime NOT NULL,
  `amount` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `vendor_id` int(10) UNSIGNED NOT NULL,
  `vendor_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_tax_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendor_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendor_address` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exp_bill_histories`
--

CREATE TABLE `exp_bill_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bill_id` int(10) UNSIGNED NOT NULL,
  `status_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notify` tinyint(1) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exp_bill_items`
--

CREATE TABLE `exp_bill_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bill_id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` decimal(7,2) NOT NULL,
  `price` decimal(15,4) NOT NULL,
  `total` decimal(15,4) NOT NULL,
  `tax` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exp_bill_item_taxes`
--

CREATE TABLE `exp_bill_item_taxes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bill_id` int(10) UNSIGNED NOT NULL,
  `bill_item_id` int(10) UNSIGNED NOT NULL,
  `tax_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exp_bill_payments`
--

CREATE TABLE `exp_bill_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bill_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `paid_at` datetime NOT NULL,
  `amount` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `reconciled` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exp_bill_statuses`
--

CREATE TABLE `exp_bill_statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `exp_bill_statuses`
--

INSERT INTO `exp_bill_statuses` (`id`, `comp_code`, `name`, `code`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '001', 'Draft', 'draft', NULL, NULL, NULL),
(2, '001', 'Received', 'received', NULL, NULL, NULL),
(3, '001', 'Partial', 'partial', NULL, NULL, NULL),
(4, '001', 'Paid', 'paid', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `exp_bill_totals`
--

CREATE TABLE `exp_bill_totals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bill_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sort_order` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inc_invoices`
--

CREATE TABLE `inc_invoices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_status_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiced_at` datetime NOT NULL,
  `due_at` datetime NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `customer_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_tax_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `category_id` int(11) NOT NULL DEFAULT '1',
  `parent_id` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inc_invoice_histories`
--

CREATE TABLE `inc_invoice_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` bigint(20) NOT NULL,
  `status_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notify` tinyint(4) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inc_invoice_items`
--

CREATE TABLE `inc_invoice_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` bigint(20) NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(7,2) NOT NULL,
  `price` decimal(15,4) NOT NULL,
  `total` decimal(15,4) NOT NULL,
  `tax` decimal(15,4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inc_invoice_item_taxes`
--

CREATE TABLE `inc_invoice_item_taxes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` bigint(20) NOT NULL,
  `invoice_item_id` bigint(20) NOT NULL,
  `tax_id` bigint(20) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inc_invoice_payments`
--

CREATE TABLE `inc_invoice_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` bigint(20) NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `paid_at` datetime NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reconciled` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inc_invoice_statuses`
--

CREATE TABLE `inc_invoice_statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inc_invoice_totals`
--

CREATE TABLE `inc_invoice_totals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` bigint(20) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_12_094604_create_expense_tables', 1),
(4, '2019_08_13_072203_create_tour_tables', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `paid_at` datetime NOT NULL,
  `amount` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `vendor_id` int(10) UNSIGNED DEFAULT NULL,
  `narration` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `catg_id` int(10) UNSIGNED NOT NULL,
  `mode_id` int(10) UNSIGNED NOT NULL,
  `exp_permit_user` int(10) UNSIGNED DEFAULT NULL,
  `exp_in_user` int(10) UNSIGNED DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A',
  `note` text COLLATE utf8mb4_unicode_ci,
  `req_approval` tinyint(1) NOT NULL DEFAULT '0',
  `reconciled` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `comp_code`, `account_id`, `paid_at`, `amount`, `vendor_id`, `narration`, `catg_id`, `mode_id`, `exp_permit_user`, `exp_in_user`, `email`, `status`, `note`, `req_approval`, `reconciled`, `created_at`, `updated_at`) VALUES
(1, '001', 0, '2019-09-02 00:00:00', '46456.0000', 0, 'tstasdst', 1, 1, 0, 0, NULL, 'A', 'fsdfs', 0, 0, '2019-09-02 02:00:08', '2019-09-02 02:00:08');

-- --------------------------------------------------------

--
-- Table structure for table `tours`
--

CREATE TABLE `tours` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_id` bigint(20) UNSIGNED NOT NULL,
  `purpose` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adv_amt` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `start_loc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `end_loc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tours`
--

INSERT INTO `tours` (`id`, `comp_code`, `emp_id`, `purpose`, `adv_amt`, `start_loc`, `end_loc`, `note`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '002', 6, '1 purpose', '1000.0000', '1 start loc', '1 end loc', '1 note', '2019-08-31 01:12:23', '2019-08-31 01:12:23', '2019-08-31 01:12:23'),
(2, '002', 6, '2 purpose', '1000.0000', '2 start loc', '2 end loc', '2 note', '2019-09-01 23:34:27', '2019-09-01 23:34:27', NULL),
(3, '002', 6, '3 purpose', '2000.0000', '3 start loc', '3 end loc', '3 note', '2019-09-01 23:36:31', '2019-09-01 23:36:31', NULL),
(4, '001', 6, 'off', '1000.0000', 'indore', 'ratlam', 'nil', '2019-09-02 09:43:04', '2019-09-02 09:43:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tour_stages`
--

CREATE TABLE `tour_stages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tour_id` bigint(20) UNSIGNED NOT NULL,
  `creator_id` bigint(20) UNSIGNED NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tour_stages`
--

INSERT INTO `tour_stages` (`id`, `tour_id`, `creator_id`, `note`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 1, NULL, 1, '2019-08-31 01:12:23', '2019-08-31 01:12:23', NULL),
(10, 1, 6, NULL, 2, '2019-08-31 06:03:21', '2019-08-31 06:03:21', NULL),
(11, 1, 2, NULL, 3, '2019-08-31 06:05:57', '2019-08-31 06:05:57', NULL),
(12, 1, 4, NULL, 4, '2019-08-31 06:10:14', '2019-08-31 06:10:14', NULL),
(13, 2, 1, NULL, 1, '2019-09-01 23:34:27', '2019-09-01 23:34:27', NULL),
(14, 3, 1, NULL, 1, '2019-09-01 23:36:31', '2019-09-01 23:36:31', NULL),
(15, 2, 6, NULL, 2, '2019-09-01 23:37:50', '2019-09-01 23:37:50', NULL),
(16, 2, 2, NULL, 3, '2019-09-01 23:38:32', '2019-09-01 23:38:32', NULL),
(17, 3, 2, NULL, 3, '2019-09-01 23:39:40', '2019-09-01 23:39:40', NULL),
(18, 2, 4, NULL, 4, '2019-09-01 23:40:15', '2019-09-01 23:40:15', NULL),
(19, 3, 4, NULL, 4, '2019-09-01 23:40:25', '2019-09-01 23:40:25', NULL),
(20, 3, 1, NULL, 5, '2019-09-01 23:48:08', '2019-09-01 23:48:08', NULL),
(21, 2, 2, NULL, 5, '2019-09-01 23:48:30', '2019-09-01 23:48:30', NULL),
(22, 4, 1, NULL, 1, '2019-09-02 09:43:04', '2019-09-02 09:43:04', NULL),
(23, 4, 2, NULL, 3, '2019-09-02 09:44:23', '2019-09-02 09:44:23', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tour_status`
--

CREATE TABLE `tour_status` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tour_status`
--

INSERT INTO `tour_status` (`id`, `title`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Created', NULL, NULL, NULL),
(2, 'TL approval', NULL, NULL, NULL),
(3, 'YS Sir approval', NULL, NULL, NULL),
(4, 'Advance Amount Released', NULL, NULL, NULL),
(5, 'Tour started', NULL, NULL, NULL),
(6, 'Tour ended', NULL, NULL, NULL),
(7, 'HS Sir Approval', NULL, NULL, NULL),
(8, 'Account Final', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Ayush Likhar', 'alikhar@laxyo.in', NULL, '$2y$10$N7gbTiJWckHPdc1ClBWxaOkoIBHewvFuxotv5bWB4OmP5ziCifiry', NULL, '2019-08-31 01:11:56', '2019-08-31 01:11:56'),
(2, 'Y Sir', 'ysir@laxyo.in', NULL, '$2y$10$Da8fVeINt6GXhSdMKLEtge20nKz29xZ9adffT9XKNTKO8XC895pYC', 'DYf9lb5eJ7xaBZHp9D32MJL7IJZp0T21QsWPHYHgqF7tYpC4ZfuKbXa3h5BT', '2019-08-31 01:11:56', '2019-08-31 01:11:56'),
(3, 'HS Sir', 'hsir@laxyo.in', NULL, '$2y$10$D6/qxrnZyUpc7DBrFqC6aeZzNPQzJmcF3VFAV7Sf7pr21iEjHsicS', NULL, '2019-08-31 01:11:56', '2019-08-31 01:11:56'),
(4, 'HR- user', 'hr@laxyo.in', NULL, '$2y$10$qUAEYk1avGnTvF/iXkOosO.ooQPSnsSMQJjejKutBG/WtwN5sAAWG', NULL, '2019-08-31 01:11:56', '2019-08-31 01:11:56'),
(5, 'TL comp 1', 'tl1@laxyo.in', NULL, '$2y$10$Zl9pBt7gyQ7CR451JeW88uVa2HFyK97cTkgUoGofQKvRfN.QJlmgy', NULL, '2019-08-31 01:11:56', '2019-08-31 01:11:56'),
(6, 'TL comp 2', 'tl2@laxyo.in', NULL, '$2y$10$ktrDsLVYAoGOCEc9a7WCre6/RaAugGXYs1m44YdvUtXpyURqO/Gui', NULL, '2019-08-31 01:11:56', '2019-08-31 01:11:56');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comp_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_ifsc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `comp_code`, `name`, `email`, `tax_number`, `acc_no`, `acc_name`, `acc_ifsc`, `phone`, `address`, `website`, `enabled`, `note`, `created_at`, `updated_at`) VALUES
(1, '001', 'rahul', 'rahul@gmail.com', NULL, NULL, NULL, NULL, NULL, 'dsds', NULL, 1, 'sdsd', '2019-09-02 02:00:50', '2019-09-02 02:00:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_mast`
--
ALTER TABLE `account_mast`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comp_grp`
--
ALTER TABLE `comp_grp`
  ADD PRIMARY KEY (`grp_code`);

--
-- Indexes for table `comp_mast`
--
ALTER TABLE `comp_mast`
  ADD PRIMARY KEY (`comp_code`);

--
-- Indexes for table `desg_mast`
--
ALTER TABLE `desg_mast`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_grade_mast`
--
ALTER TABLE `emp_grade_mast`
  ADD PRIMARY KEY (`grade_code`);

--
-- Indexes for table `emp_mast`
--
ALTER TABLE `emp_mast`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `expense_catg_mast`
--
ALTER TABLE `expense_catg_mast`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense_mode_mast`
--
ALTER TABLE `expense_mode_mast`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense_site_mast`
--
ALTER TABLE `expense_site_mast`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exp_bills`
--
ALTER TABLE `exp_bills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exp_bill_histories`
--
ALTER TABLE `exp_bill_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exp_bill_items`
--
ALTER TABLE `exp_bill_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exp_bill_item_taxes`
--
ALTER TABLE `exp_bill_item_taxes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exp_bill_payments`
--
ALTER TABLE `exp_bill_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exp_bill_statuses`
--
ALTER TABLE `exp_bill_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exp_bill_totals`
--
ALTER TABLE `exp_bill_totals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inc_invoices`
--
ALTER TABLE `inc_invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inc_invoice_histories`
--
ALTER TABLE `inc_invoice_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inc_invoice_items`
--
ALTER TABLE `inc_invoice_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inc_invoice_item_taxes`
--
ALTER TABLE `inc_invoice_item_taxes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inc_invoice_payments`
--
ALTER TABLE `inc_invoice_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inc_invoice_statuses`
--
ALTER TABLE `inc_invoice_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inc_invoice_totals`
--
ALTER TABLE `inc_invoice_totals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tours`
--
ALTER TABLE `tours`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour_stages`
--
ALTER TABLE `tour_stages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour_status`
--
ALTER TABLE `tour_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_mast`
--
ALTER TABLE `account_mast`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `desg_mast`
--
ALTER TABLE `desg_mast`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `emp_mast`
--
ALTER TABLE `emp_mast`
  MODIFY `emp_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `expense_catg_mast`
--
ALTER TABLE `expense_catg_mast`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `expense_mode_mast`
--
ALTER TABLE `expense_mode_mast`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `expense_site_mast`
--
ALTER TABLE `expense_site_mast`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exp_bills`
--
ALTER TABLE `exp_bills`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exp_bill_histories`
--
ALTER TABLE `exp_bill_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exp_bill_items`
--
ALTER TABLE `exp_bill_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exp_bill_item_taxes`
--
ALTER TABLE `exp_bill_item_taxes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exp_bill_payments`
--
ALTER TABLE `exp_bill_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exp_bill_statuses`
--
ALTER TABLE `exp_bill_statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `exp_bill_totals`
--
ALTER TABLE `exp_bill_totals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inc_invoices`
--
ALTER TABLE `inc_invoices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inc_invoice_histories`
--
ALTER TABLE `inc_invoice_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inc_invoice_items`
--
ALTER TABLE `inc_invoice_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inc_invoice_item_taxes`
--
ALTER TABLE `inc_invoice_item_taxes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inc_invoice_payments`
--
ALTER TABLE `inc_invoice_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inc_invoice_statuses`
--
ALTER TABLE `inc_invoice_statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inc_invoice_totals`
--
ALTER TABLE `inc_invoice_totals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tours`
--
ALTER TABLE `tours`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tour_stages`
--
ALTER TABLE `tour_stages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `tour_status`
--
ALTER TABLE `tour_status`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
